struct numbers {
    int a;
    double b;
};

int i;
numbers n;

// Direct access
i = 1;
n.a = 2;

// Access through pointer
int *pi = &i;
*pi = 3;

numbers *pn = &n;
pn->b = 4.0;
