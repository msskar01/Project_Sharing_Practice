struct numbers {
    int a;
    double b;
};

int i;
numbers n;

// Direct access
i = 1;
n.a = 2;

// Access through reference
int &ri = i;
ri = 3;

numbers &rn = n;
rn.b = 4.0;
