class Point {
public:
    Point(int a, int b) : x(a), y(b)
    {}

    Point operator+(const Point & rhs) const {
        return {x + rhs.x, y + rhs.y};
    }

    Point operator++() {  // prefix
        ++x;
        ++y;
        return *this;
    }

    Point operator++(int) {}  // postfix

private:
    int x, y;
}
