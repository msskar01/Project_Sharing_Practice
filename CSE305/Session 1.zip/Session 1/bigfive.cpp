#include <cstring>
#include <utility>

class StringHolder {
    char *str;

    StringHolder(const char *s, std::size_t n)
    : str(new char[n]) {
        std::memcpy(str, s, n);
    }

public:
    StringHolder(const char *s = "")
    : StringHolder(s, std::strlen(s) + 1)
    {}
}


~StringHolder() {
    delete[] str;
}

StringHolder(const StringHolder & rhs)
: StringHolder(rhs.str)
{}

StringHolder(const StringHolder && rhs)
: str(std::exchange(rhs.str, nullptr))
{}

StringHolder & operator=(const StringHolder & rhs) {
    return *this = StringHolder(rhs);
}

StringHolder & operator=(StringHolder && rhs) {
    std::swap(str, rhs.str);
    return *this;
}
