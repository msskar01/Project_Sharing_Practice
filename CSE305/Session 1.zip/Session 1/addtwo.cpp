void addTwo(int *pi) {
    (*pi) += 2;
}

int i = 0;
addTwo(&i);
printf("%d\n", i);  // 2

void addTwo(int &ri) {
    ri += 2;
}

int i = 0;
addTwo(i);
printf("%d\n", i);  // 2

void addTwo(int i) {
    i += 2;
}

int i = 0;
addTwo(i);
printf("%d\n", i);  // 0
