class C {
public:
    C(int a, int b) {
        x = a;
        y = b;
    }

    // Alternate way (list initialization)
    C(int a, int b) : x(a), y(b)
    {}

private:
    int x;
    int y;
};



// main method
C c {5, 3};
C c = {5, 3};

C *pc = new C {5, 3};
delete pc;


C returnC() {
    return {1, 2};
}







