#include<iostream>
#include<vector>
#include<string>

using namespace std;

class Instruction
{
public:
    void set_values(vector<string>);
    vector<string> get_steps();
private:
    vector<string> steps;
};

void Instruction::set_values(vector<string> s)
{
    steps = s;
}

vector<string> Instruction::get_steps()
{
    return steps;
}

void singleCycle()
{
    int instructionCount, numberOfSteps, stepLength, cycleLength = 0, cycles = 0;
    vector<Instruction> instructions;

    cout << "specify how many instructions you want to simulate" << endl;
    cin >> instructionCount;
    cout << "specify how long each step will take in nano seconds for each instructions' sub-steps" << endl;
    cin >> stepLength;

    for (int i = 1; i <= instructionCount; i++)
    {
        vector<string> steps;
        Instruction instruction;
        cout << "specify how many steps are in instuction " << i << endl;
        cin >> numberOfSteps;
        for (int i = 0; i < numberOfSteps; i++)
        {
            steps.push_back(to_string(i));
        }
        instruction.set_values(steps);
        instructions.push_back(instruction);

        //Find longest instruction and set cycle length to it
        if (cycleLength < (stepLength * numberOfSteps))
        {
            cycleLength = stepLength * numberOfSteps;
        }
    }

    for (int i = 1; i <= instructions.size(); i++)
    {
        cycles++;
        cout << "cuurent state instruciton " << i << endl;
    }

    cout << "number of cycles: " << cycles << " time per cycle: " << cycleLength << " time took to preform cycles: " << (cycles * cycleLength) << " nano seconds" << endl;
}

void multiCycle()
{
    int instructionCount, numberOfSteps, stepLength, cycleLength = 0, cycles = 0;
    vector<Instruction> instructions;

    cout << "specify how many instructions you want to simulate" << endl;
    cin >> instructionCount;
    cout << "specify how long each step will take in nano seconds for each instruction's sub-steps" << endl;
    cin >> stepLength;
    cycleLength = stepLength;

    for (int i = 1; i <= instructionCount; i++)
    {
        vector<string> steps;
        Instruction instruction;
        cout << "specify how many steps are in instuction " << i << endl;
        cin >> numberOfSteps;
        for (int i = 0; i < numberOfSteps; i++)
        {
            steps.push_back(to_string(i));
        }
        instruction.set_values(steps);
        instructions.push_back(instruction);
    }

    for (int i = 1; i <= instructions.size(); i++)
    {
        for (int j = 1; j <= instructions[i - 1].get_steps().size(); j++)
        {
            cycles++;
            cout << "cycle " << cycles << ": cuurent state instruciton " << i << " step " << j << endl;
        }
    }

    cout << "number of cycles: " << cycles << " time per cycle: " << cycleLength << " time took to preform cycles: " << (cycles * cycleLength) << " nano seconds" << endl;
}

vector<Instruction> process(vector<Instruction> pipeline)
{
    if (pipeline.size() == 0)
    {
        return pipeline;
    }

    cout << "current steps ";
    for (int i = 0; i < pipeline.size(); i++)
    {
        if (!pipeline[i].get_steps().empty())
        {
            vector<string> steps = pipeline[i].get_steps();
            cout << steps.front();
            steps.erase(steps.begin());
            pipeline[i].set_values(steps);
            if (pipeline[i].get_steps().empty())
            {
                pipeline.erase(pipeline.begin() + i);
            }
        }
    }
    cout << endl;
    return pipeline;
}

void pipelined()
{
    int instructionCount, numberOfSteps, stepLength, cycleLength = 0, cycles = 0, pipelineSzie;
    vector<Instruction> instructions;

    cout << "specify how many instructions you want to simulate" << endl;
    cin >> instructionCount;
    cout << "specify how long each step will take in nano seconds for each instruction's sub-steps" << endl;
    cin >> stepLength;
    cycleLength = stepLength;
    cout << "how many steps can the pipeline hold" << endl;
    cin >> pipelineSzie;
    vector<Instruction> pipeline;

    for (int i = 1; i <= instructionCount; i++)
    {
        vector<string> steps;
        Instruction instruction;
        cout << "specify how many steps are in instuction " << i << endl;
        cin >> numberOfSteps;

        //To avoid any posibility of dealing with hazards
        if (numberOfSteps > pipelineSzie)
        {
            cout << "invalid number of steps for how large pipeline is, could run into hazards";
            return;
        }

        for (int i = 0; i < numberOfSteps; i++)
        {
            steps.push_back(to_string(i));
        }
        instruction.set_values(steps);
        instructions.push_back(instruction);
    }

    int i = instructions.size();

    while (i != 0 || !pipeline.empty())
    {
        pipeline = process(pipeline);
        if (i > 0)
        {
            pipeline.insert(pipeline.begin(), instructions[i - 1]);
            i--;
        }
        cycles++;
    }
    cycles--;

    cout << "number of cycles: " << cycles << " time per cycle: " << cycleLength << " time took to preform cycles: " << (cycles * cycleLength) << " nano seconds" << endl;
}



int main()
{
    string enter;
    cout << "enter in the simulation you wish to run" << endl;
    cin >> enter;
    if (enter == "pipelined")
    {
        pipelined();
    }
    else if (enter == "single cycle")
    {
        singleCycle();
    }
    else if (enter == "multi cycle")
    {
        multiCycle();
    }
    else
    {
        cout << "the input was invalid run the program again";
    }
    
    cin.get();
}